Void Reaver + Thunder Strike  (Fabric, Minecraft 1.21.11)

BUILD THE .JAR
 A) On GitHub (works from a phone): create a repo, upload everything in this
    folder (including the .github folder), open the Actions tab, run "build",
    then download the artifact "voidreaver-jar" -> voidreaver-1.0.0.jar
 B) On PC: install Java 21 + Gradle 9.2.1, run:  gradle build
    Jar is in build/libs/voidreaver-1.0.0.jar

INSTALL
 Put the jar in .minecraft/mods together with Fabric Loader 0.18+ and Fabric API for 1.21.11.

CONTENT
 - Void Reaver: mace + axe + sword in one (smash damage by fall height, breaks shields,
   takes Density/Breach/Wind Burst and sword/axe enchants).
   Craft: Netherite Axe, Netherite Sword, Mace (top row) + 2 Netherite Ingots (handle).
 - Thunder Strike I-V: works on swords, axes, mace, trident, bow, crossbow, spear.
   Every 4th hit calls lightning. Damage = 6 + 4 x level, sets target on fire,
   level III+ chains to nearby mobs. Get it from enchanting table, villagers, or creative book.
