package com.voidreaver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

/**
 * Thunder Strike enchantment logic: every 4th hit with an enchanted weapon
 * (melee, bow, crossbow, trident...) calls lightning. Higher level = more damage.
 */
public final class ThunderStrike {
    private static final int HITS_NEEDED = 4;
    private static final Map<UUID, Integer> HITS = new HashMap<>();

    private ThunderStrike() {}

    public static void register() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
            if (blocked || damageTaken <= 0.0f) return;
            if (!(entity.getEntityWorld() instanceof ServerWorld world)) return;
            if (!(source.getAttacker() instanceof LivingEntity attacker) || attacker == entity) return;

            ItemStack weapon = source.getWeaponStack();
            if (weapon == null || weapon.isEmpty()) return;

            int level = world.getRegistryManager()
                    .getOrThrow(RegistryKeys.ENCHANTMENT)
                    .getOptional(VoidReaverMod.THUNDER_STRIKE)
                    .map(e -> EnchantmentHelper.getLevel(e, weapon))
                    .orElse(0);
            if (level <= 0) return;

            UUID id = attacker.getUuid();
            int hits = HITS.merge(id, 1, Integer::sum);
            if (hits < HITS_NEEDED) {
                if (attacker instanceof ServerPlayerEntity player) {
                    player.sendMessage(Text.literal("\u26A1 " + hits + "/" + HITS_NEEDED), true);
                }
                return;
            }
            HITS.remove(id);
            strike(world, entity, attacker, level);
        });
    }

    private static void strike(ServerWorld world, LivingEntity target, LivingEntity attacker, int level) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world, SpawnReason.TRIGGERED);
        if (bolt != null) {
            bolt.setPosition(target.getX(), target.getY(), target.getZ());
            bolt.setCosmetic(true); // visuals + sound only; damage is handled below
            world.spawnEntity(bolt);
        }

        float damage = 6.0f + 4.0f * level;
        target.damage(world, world.getDamageSources().lightningBolt(), damage);
        target.setOnFireFor(2.0f * level);

        // Level III+: lightning chains to nearby mobs for half damage.
        if (level >= 3) {
            double radius = 2.0 + level;
            List<Entity> nearby = world.getOtherEntities(target, target.getBoundingBox().expand(radius),
                    e -> e instanceof LivingEntity le && le != attacker && le.isAlive());
            for (Entity e : nearby) {
                if (e instanceof LivingEntity living) {
                    living.damage(world, world.getDamageSources().lightningBolt(), damage * 0.5f);
                    living.setOnFireFor(level);
                }
            }
        }
    }
}
