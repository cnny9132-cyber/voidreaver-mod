package com.voidreaver;

import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;

/**
 * Void Reaver extends the vanilla Mace: keeps the smash attack
 * (higher fall = more damage) and works with Density / Breach / Wind Burst.
 * Shield breaking comes from the WEAPON component set in VoidReaverMod.
 */
public class VoidReaverItem extends MaceItem {

    public VoidReaverItem(Item.Settings settings) {
        super(settings);
    }

    public static AttributeModifiersComponent attributes() {
        return AttributeModifiersComponent.builder()
                .add(EntityAttributes.ATTACK_DAMAGE,
                        new EntityAttributeModifier(Item.BASE_ATTACK_DAMAGE_MODIFIER_ID, 10.0,
                                EntityAttributeModifier.Operation.ADD_VALUE),
                        AttributeModifierSlot.MAINHAND)
                .add(EntityAttributes.ATTACK_SPEED,
                        new EntityAttributeModifier(Item.BASE_ATTACK_SPEED_MODIFIER_ID, -3.0,
                                EntityAttributeModifier.Operation.ADD_VALUE),
                        AttributeModifierSlot.MAINHAND)
                .build();
    }

    @Override
    public void postDamageEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        super.postDamageEntity(stack, target, attacker);
        if (target.getEntityWorld() instanceof ServerWorld world) {
            world.spawnParticles(ParticleTypes.REVERSE_PORTAL,
                    target.getX(), target.getBodyY(0.5), target.getZ(),
                    30, 0.4, 0.5, 0.4, 0.1);
        }
    }
}
