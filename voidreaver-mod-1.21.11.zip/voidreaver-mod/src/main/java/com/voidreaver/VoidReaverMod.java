package com.voidreaver;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.WeaponComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class VoidReaverMod implements ModInitializer {
    public static final String MOD_ID = "voidreaver";

    public static final RegistryKey<Item> VOID_REAVER_KEY =
            RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "void_reaver"));

    public static final RegistryKey<Enchantment> THUNDER_STRIKE =
            RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(MOD_ID, "thunder_strike"));

    public static final Item VOID_REAVER = Registry.register(
            Registries.ITEM,
            VOID_REAVER_KEY,
            new VoidReaverItem(new Item.Settings()
                    .registryKey(VOID_REAVER_KEY)
                    .rarity(Rarity.EPIC)
                    .maxDamage(2500)
                    .fireproof()
                    .enchantable(20)
                    .repairable(Items.NETHERITE_INGOT)
                    .attributeModifiers(VoidReaverItem.attributes())
                    .component(DataComponentTypes.TOOL, MaceItem.createToolComponent())
                    // 1 durability per hit, disables enemy shields for 10 seconds (axe ability)
                    .component(DataComponentTypes.WEAPON, new WeaponComponent(1, 10.0f))));

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(VOID_REAVER));
        ThunderStrike.register();
    }
}
